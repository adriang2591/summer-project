#pragma once
#include <iostream>
#include <string>
#include <fstream>
//#include "AdminForm.h"
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>


namespace Project1 {

	using namespace System;
	using namespace std;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for InsertForm
	/// </summary>
	public ref class InsertForm : public System::Windows::Forms::Form
	{
	public:
		InsertForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~InsertForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtGrade;
	private: System::Windows::Forms::TextBox^  txtLast;
	private: System::Windows::Forms::TextBox^  txtID;
	protected:


	protected:




	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  btnSet;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtFirst;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtGPA;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtCourse2;
	private: System::Windows::Forms::TextBox^  txtCourse1;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtGrade = (gcnew System::Windows::Forms::TextBox());
			this->txtLast = (gcnew System::Windows::Forms::TextBox());
			this->txtID = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btnSet = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtFirst = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtGPA = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtCourse2 = (gcnew System::Windows::Forms::TextBox());
			this->txtCourse1 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// txtGrade
			// 
			this->txtGrade->Location = System::Drawing::Point(167, 180);
			this->txtGrade->Name = L"txtGrade";
			this->txtGrade->Size = System::Drawing::Size(116, 20);
			this->txtGrade->TabIndex = 0;
			// 
			// txtLast
			// 
			this->txtLast->Location = System::Drawing::Point(167, 136);
			this->txtLast->Name = L"txtLast";
			this->txtLast->Size = System::Drawing::Size(116, 20);
			this->txtLast->TabIndex = 2;
			// 
			// txtID
			// 
			this->txtID->Location = System::Drawing::Point(167, 47);
			this->txtID->Name = L"txtID";
			this->txtID->Size = System::Drawing::Size(116, 20);
			this->txtID->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(93, 50);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(61, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"Student ID:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(93, 139);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(61, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Last Name:";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(46, 187);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(108, 13);
			this->label4->TabIndex = 7;
			this->label4->Text = L"Student Grade Level:";
			// 
			// btnSet
			// 
			this->btnSet->Location = System::Drawing::Point(125, 350);
			this->btnSet->Name = L"btnSet";
			this->btnSet->Size = System::Drawing::Size(75, 23);
			this->btnSet->TabIndex = 8;
			this->btnSet->Text = L"Set";
			this->btnSet->UseVisualStyleBackColor = true;
			this->btnSet->Click += gcnew System::EventHandler(this, &InsertForm::btnSet_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(76, 9);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(207, 18);
			this->label5->TabIndex = 9;
			this->label5->Text = L"Enter the following details:";
			// 
			// txtFirst
			// 
			this->txtFirst->Location = System::Drawing::Point(167, 93);
			this->txtFirst->Name = L"txtFirst";
			this->txtFirst->Size = System::Drawing::Size(116, 20);
			this->txtFirst->TabIndex = 10;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(94, 100);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(60, 13);
			this->label3->TabIndex = 11;
			this->label3->Text = L"First Name:";
			// 
			// txtGPA
			// 
			this->txtGPA->Location = System::Drawing::Point(167, 302);
			this->txtGPA->Name = L"txtGPA";
			this->txtGPA->Size = System::Drawing::Size(116, 20);
			this->txtGPA->TabIndex = 12;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(119, 305);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(32, 13);
			this->label6->TabIndex = 13;
			this->label6->Text = L"GPA:";
			// 
			// txtCourse2
			// 
			this->txtCourse2->Location = System::Drawing::Point(167, 266);
			this->txtCourse2->Name = L"txtCourse2";
			this->txtCourse2->Size = System::Drawing::Size(116, 20);
			this->txtCourse2->TabIndex = 14;
			// 
			// txtCourse1
			// 
			this->txtCourse1->Location = System::Drawing::Point(167, 228);
			this->txtCourse1->Name = L"txtCourse1";
			this->txtCourse1->Size = System::Drawing::Size(116, 20);
			this->txtCourse1->TabIndex = 15;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(102, 269);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(52, 13);
			this->label7->TabIndex = 16;
			this->label7->Text = L"Course 2:";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(102, 231);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(52, 13);
			this->label8->TabIndex = 17;
			this->label8->Text = L"Course 1:";
			// 
			// InsertForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(351, 394);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtCourse1);
			this->Controls->Add(this->txtCourse2);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtGPA);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtFirst);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->btnSet);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtID);
			this->Controls->Add(this->txtLast);
			this->Controls->Add(this->txtGrade);
			this->Name = L"InsertForm";
			this->Text = L"Insert New Student";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnSet_Click(System::Object^  sender, System::EventArgs^  e) 
	{
		InsertForm::Visible = false;

		String ^ tempID, ^ tempFirst, ^ tempLast, ^ tempGrade, ^ tempCourse1, ^ tempCourse2,  ^ tempGPA;

		tempID = txtID->Text;
		tempFirst = txtFirst->Text;
		tempLast = txtLast->Text;
		tempGrade = txtGrade->Text;
		tempCourse1 = txtCourse1->Text;
		tempCourse2 = txtCourse2->Text;
		tempGPA = txtGPA->Text;

		string ID = msclr::interop::marshal_as<string>(tempID);
		string firstname = msclr::interop::marshal_as<string>(tempFirst);
		string lastname = msclr::interop::marshal_as<string>(tempLast);
		string grade = msclr::interop::marshal_as<string>(tempGrade);
		string course1 = msclr::interop::marshal_as<string>(tempCourse1);
		string course2 = msclr::interop::marshal_as<string>(tempCourse2);
		string gpa = msclr::interop::marshal_as<string>(tempGPA);

		ofstream outFile;
		outFile.open("studentDB.txt", ios::app);
		outFile << ID <<" "<< firstname << " " << lastname << " " << grade << " " << course1 << " " << course2 << " " << gpa << endl;
		outFile.close();

		MessageBox::Show("New Student Added!");
		
	}
};
}
