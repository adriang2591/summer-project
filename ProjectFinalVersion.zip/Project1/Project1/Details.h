#pragma once

namespace Project1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Details
	/// </summary>
	public ref class Details : public System::Windows::Forms::Form
	{
	public:
		Details(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Details()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::Label^  lblGPA;
	protected:
	public: System::Windows::Forms::Label^  lblGrade;
	public: System::Windows::Forms::Label^  lblLast;
	public: System::Windows::Forms::Label^  lblFirst;
	public: System::Windows::Forms::Label^  lblID;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	public: System::Windows::Forms::Label^  lblCourse2;
	public: System::Windows::Forms::Label^  lblCourse1;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblGPA = (gcnew System::Windows::Forms::Label());
			this->lblGrade = (gcnew System::Windows::Forms::Label());
			this->lblLast = (gcnew System::Windows::Forms::Label());
			this->lblFirst = (gcnew System::Windows::Forms::Label());
			this->lblID = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->lblCourse2 = (gcnew System::Windows::Forms::Label());
			this->lblCourse1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// lblGPA
			// 
			this->lblGPA->AutoSize = true;
			this->lblGPA->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblGPA->Location = System::Drawing::Point(152, 305);
			this->lblGPA->Name = L"lblGPA";
			this->lblGPA->Size = System::Drawing::Size(45, 16);
			this->lblGPA->TabIndex = 1;
			this->lblGPA->Text = L"label2";
			// 
			// lblGrade
			// 
			this->lblGrade->AutoSize = true;
			this->lblGrade->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblGrade->Location = System::Drawing::Point(152, 177);
			this->lblGrade->Name = L"lblGrade";
			this->lblGrade->Size = System::Drawing::Size(45, 16);
			this->lblGrade->TabIndex = 2;
			this->lblGrade->Text = L"label3";
			// 
			// lblLast
			// 
			this->lblLast->AutoSize = true;
			this->lblLast->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblLast->Location = System::Drawing::Point(152, 132);
			this->lblLast->Name = L"lblLast";
			this->lblLast->Size = System::Drawing::Size(45, 16);
			this->lblLast->TabIndex = 3;
			this->lblLast->Text = L"label4";
			// 
			// lblFirst
			// 
			this->lblFirst->AutoSize = true;
			this->lblFirst->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblFirst->Location = System::Drawing::Point(152, 88);
			this->lblFirst->Name = L"lblFirst";
			this->lblFirst->Size = System::Drawing::Size(45, 16);
			this->lblFirst->TabIndex = 4;
			this->lblFirst->Text = L"label5";
			// 
			// lblID
			// 
			this->lblID->AutoSize = true;
			this->lblID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblID->Location = System::Drawing::Point(152, 45);
			this->lblID->Name = L"lblID";
			this->lblID->Size = System::Drawing::Size(45, 16);
			this->lblID->TabIndex = 5;
			this->lblID->Text = L"label6";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(40, 45);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(72, 16);
			this->label7->TabIndex = 6;
			this->label7->Text = L"Student ID:";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(40, 305);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(39, 16);
			this->label8->TabIndex = 7;
			this->label8->Text = L"GPA:";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(40, 177);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(88, 16);
			this->label9->TabIndex = 8;
			this->label9->Text = L"Grade Level: ";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(40, 132);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(76, 16);
			this->label10->TabIndex = 9;
			this->label10->Text = L"Last Name:";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(40, 88);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(79, 16);
			this->label11->TabIndex = 10;
			this->label11->Text = L"First Name: ";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(40, 262);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(64, 16);
			this->label1->TabIndex = 11;
			this->label1->Text = L"Course 2:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(40, 218);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(64, 16);
			this->label2->TabIndex = 12;
			this->label2->Text = L"Course 1:";
			// 
			// lblCourse2
			// 
			this->lblCourse2->AutoSize = true;
			this->lblCourse2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblCourse2->Location = System::Drawing::Point(152, 262);
			this->lblCourse2->Name = L"lblCourse2";
			this->lblCourse2->Size = System::Drawing::Size(45, 16);
			this->lblCourse2->TabIndex = 13;
			this->lblCourse2->Text = L"label3";
			// 
			// lblCourse1
			// 
			this->lblCourse1->AutoSize = true;
			this->lblCourse1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblCourse1->Location = System::Drawing::Point(152, 218);
			this->lblCourse1->Name = L"lblCourse1";
			this->lblCourse1->Size = System::Drawing::Size(45, 16);
			this->lblCourse1->TabIndex = 14;
			this->lblCourse1->Text = L"label4";
			// 
			// Details
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 366);
			this->Controls->Add(this->lblCourse1);
			this->Controls->Add(this->lblCourse2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->lblID);
			this->Controls->Add(this->lblFirst);
			this->Controls->Add(this->lblLast);
			this->Controls->Add(this->lblGrade);
			this->Controls->Add(this->lblGPA);
			this->Name = L"Details";
			this->Text = L"Details";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}
