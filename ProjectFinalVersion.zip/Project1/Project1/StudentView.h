#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include "Details.h"
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>


namespace Project1 {

	using namespace System;
	using namespace std;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for StudentView
	/// </summary>
	public ref class StudentView : public System::Windows::Forms::Form
	{
	public:
		StudentView(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StudentView()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::TextBox^  txtStudentID;
	private: System::Windows::Forms::Button^  btnOK;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtStudentID = (gcnew System::Windows::Forms::TextBox());
			this->btnOK = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(123, 25);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(132, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Please enter your ID:";
			// 
			// txtStudentID
			// 
			this->txtStudentID->Location = System::Drawing::Point(126, 61);
			this->txtStudentID->Name = L"txtStudentID";
			this->txtStudentID->Size = System::Drawing::Size(100, 20);
			this->txtStudentID->TabIndex = 1;
			// 
			// btnOK
			// 
			this->btnOK->Location = System::Drawing::Point(138, 107);
			this->btnOK->Name = L"btnOK";
			this->btnOK->Size = System::Drawing::Size(75, 23);
			this->btnOK->TabIndex = 2;
			this->btnOK->Text = L"OK";
			this->btnOK->UseVisualStyleBackColor = true;
			this->btnOK->Click += gcnew System::EventHandler(this, &StudentView::btnOK_Click);
			// 
			// StudentView
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(373, 167);
			this->Controls->Add(this->btnOK);
			this->Controls->Add(this->txtStudentID);
			this->Controls->Add(this->label1);
			this->Name = L"StudentView";
			this->Text = L"StudentView";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnOK_Click(System::Object^  sender, System::EventArgs^  e) {
		String ^ num = txtStudentID->Text;
		string ID = msclr::interop::marshal_as<string>(num);

		string fileID, fileFirst, fileLast, fileGrade, fileCourse1, fileCourse2, fileGPA;
		String ^finalID, ^finalFirst, ^finalLast, ^finalGrade, ^finalCourse1, ^finalCourse2, ^finalGPA;
		ifstream inFile;
		inFile.open("studentDB.txt");

		while (inFile >> fileID >> fileFirst >> fileLast >> fileGrade >> fileCourse1 >> fileCourse2 >> fileGPA)
		{
			if (ID.compare(fileID) == 0)
			{
				finalID = msclr::interop::marshal_as<String^>(fileID);
				finalFirst = msclr::interop::marshal_as<String^>(fileFirst);
				finalLast = msclr::interop::marshal_as<String^>(fileLast);
				finalGrade = msclr::interop::marshal_as<String^>(fileGrade);
				finalCourse1 = msclr::interop::marshal_as<String^>(fileCourse1);
				finalCourse2 = msclr::interop::marshal_as<String^>(fileCourse2);
				finalGPA = msclr::interop::marshal_as<String^>(fileGPA);

				Details ^ frm = gcnew Details;

				frm->lblID->Text = finalID;
				frm->lblFirst->Text = finalFirst;
				frm->lblLast->Text = finalLast;
				frm->lblGrade->Text = finalGrade;
				frm->lblCourse1->Text = finalCourse1;
				frm->lblCourse2->Text = finalCourse2;
				frm->lblGPA->Text = finalGPA;

				frm->ShowDialog();
			}

		}
	}
	};
}
