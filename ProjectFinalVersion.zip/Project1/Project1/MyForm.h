#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include "AdminForm.h"
#include "StudentForm.h"
#include <msclr\marshal.h>
#include <msclr\marshal_cppstd.h>
#include <vcclr.h>

namespace Project1 {

	using namespace System;
	using namespace std;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	public: System::Windows::Forms::TextBox^  txtUser;
	private: System::Windows::Forms::TextBox^  txtPass;



	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  btnLogin;

	private: System::Windows::Forms::CheckBox^  adminBox;
	private: System::Windows::Forms::CheckBox^  studentBox;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtUser = (gcnew System::Windows::Forms::TextBox());
			this->txtPass = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->btnLogin = (gcnew System::Windows::Forms::Button());
			this->adminBox = (gcnew System::Windows::Forms::CheckBox());
			this->studentBox = (gcnew System::Windows::Forms::CheckBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(69, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(473, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Welcome to the Student Information Management System";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(187, 137);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(74, 16);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Username:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(187, 190);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(71, 16);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Password:";
			// 
			// txtUser
			// 
			this->txtUser->Location = System::Drawing::Point(264, 133);
			this->txtUser->Name = L"txtUser";
			this->txtUser->Size = System::Drawing::Size(100, 20);
			this->txtUser->TabIndex = 4;
			// 
			// txtPass
			// 
			this->txtPass->Location = System::Drawing::Point(264, 186);
			this->txtPass->Name = L"txtPass";
			this->txtPass->Size = System::Drawing::Size(100, 20);
			this->txtPass->TabIndex = 5;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(114, 87);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(144, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Choose a type of user: ";
			// 
			// btnLogin
			// 
			this->btnLogin->Location = System::Drawing::Point(223, 237);
			this->btnLogin->Name = L"btnLogin";
			this->btnLogin->Size = System::Drawing::Size(120, 23);
			this->btnLogin->TabIndex = 7;
			this->btnLogin->Text = L"Login";
			this->btnLogin->UseVisualStyleBackColor = true;
			this->btnLogin->Click += gcnew System::EventHandler(this, &MyForm::btnLogin_Click);
			// 
			// adminBox
			// 
			this->adminBox->AutoSize = true;
			this->adminBox->Location = System::Drawing::Point(264, 86);
			this->adminBox->Name = L"adminBox";
			this->adminBox->Size = System::Drawing::Size(55, 17);
			this->adminBox->TabIndex = 8;
			this->adminBox->Text = L"Admin";
			this->adminBox->UseVisualStyleBackColor = true;
			// 
			// studentBox
			// 
			this->studentBox->AutoSize = true;
			this->studentBox->Location = System::Drawing::Point(337, 86);
			this->studentBox->Name = L"studentBox";
			this->studentBox->Size = System::Drawing::Size(63, 17);
			this->studentBox->TabIndex = 9;
			this->studentBox->Text = L"Student";
			this->studentBox->UseVisualStyleBackColor = true;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(589, 292);
			this->Controls->Add(this->studentBox);
			this->Controls->Add(this->adminBox);
			this->Controls->Add(this->btnLogin);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtPass);
			this->Controls->Add(this->txtUser);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"System Login";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void btnLogin_Click(System::Object^  sender, System::EventArgs^  e) 
{
	if (adminBox->Checked && !studentBox->Checked)
	{
		string word;
		string next;
		ifstream inFile;
		inFile.open("admin.txt");

		String ^ userName = txtUser->Text;
		String ^ password = txtPass->Text;

		string searchUserName = msclr::interop::marshal_as<string>(userName);
		string searchPassword = msclr::interop::marshal_as<string>(password);

		while (inFile >> word >> next)
		{
			if (word.compare(searchUserName) == 0)
			{
				if (next.compare(searchPassword) == 0)
				{
					MyForm::Visible = false;
					AdminForm ^ form = gcnew AdminForm;
					form->ShowDialog();
				}

				else
					MessageBox::Show("Wrong Password");
			}

		}
	}

	else if (!adminBox->Checked && studentBox->Checked)
	{
		string word;
		string next;
		ifstream inFile;
		inFile.open("student.txt");

		String ^ userName = txtUser->Text;
		String ^ password = txtPass->Text;

		string searchUserName = msclr::interop::marshal_as<string>(userName);
		string searchPassword = msclr::interop::marshal_as<string>(password);

		while (inFile >> word >> next)
		{
			if (word.compare(searchUserName) == 0)
			{
				if (next.compare(searchPassword) == 0)
				{
					MyForm::Visible = false;
					StudentForm ^ form = gcnew StudentForm;
					form->ShowDialog();

					
				}

				else 
					MessageBox::Show("Wrong Password");
			}
		}
	}

	else
		MessageBox::Show("Please Only Check One Box");
}

};
}
