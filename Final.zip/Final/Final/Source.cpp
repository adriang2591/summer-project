#include <iostream>
#include <fstream>
#include <string>

using namespace std;


int main()
{

	const int ssize = 32;
	int answer;
	string Fname;
	string Lname;
	int space;
	char ID[ssize];
	int choice;
	int choice1;
	int exam;
	string line;


	cout << "Welcome, are you a ... " << endl;
	cout << "1) Student " << endl;
	cout << "2) Administrator " << endl;
	cin >> answer;

		if (answer == 1)
		{
			cout << "Please enter your name: " << endl;
			cin >> Fname;
			cin >> Lname;
			cout << "Now please enter your student ID number: " << endl;
			cin.getline (ID,ssize);
			cin >> ID;

			while (ID == NULL)
			{
				cout << "Invalid ID number: " << endl;
				cout << "Please re-enter the student's ID number: " << endl;
				cin >> ID;
			}

				cout << "Welcome ";
				cout << Fname;
				cout << ", what would you like to view: " << endl;
				cout << "1) Course registered" << endl;
				cout << "2) Exam scores" << endl;
				cout << "3) Semester GPA" << endl;
				cout << "4) Exit" << endl;
				cin >> choice;
			
			while (choice != 4)
			{
				
				if (choice == 1)
				{
					cout << "The course(s) you're registered are:" << endl;
					
					ifstream myfile ("Courses.txt");
					if (myfile.is_open())
					{
						while ( getline (myfile,line))
						{
							cout << line << endl;
						}
						myfile.close();
					}
					else cout << "Unable to pull up your course. " << endl;

					cout << "Would you like to view any of the other choices? " << endl;
					cout << "2) Exam scores" << endl;
					cout << "3) Semester GPA" << endl;
					cout << "4) Exit" << endl;
					cin >> choice;
					
				}

				if (choice == 2)
				{
					cout << "Your Exam scores are:" << endl;
					ifstream myfile("ExamScore.txt");
					if (myfile.is_open())
					{
						while (getline(myfile, line))
						{
							cout << line << endl;
						}
						myfile.close();
					}
					else cout << "Unable to pull up your scores. " << endl;


					cout << "Would you like to view any of the other choices? " << endl;
					cout << "1) Course(s) registered" << endl;
					cout << "3) Semester GPA" << endl;
					cout << "4) Exit" << endl;
					cin >> choice;
				}

				else
				{
					cout << "Your GPA for the semster is: " << endl;
					

					cout << "Would you like to view any of the other choices? " << endl;
					cout << "1) Course(s) registered" << endl;
					cout << "2) Exam scores" << endl;
					cout << "4) Exit" << endl;
					cin >> choice;

				}

			}
		}


		else
		{
			cout << "Please enter student's name: " << endl;
			cin >> Fname;
			cin >> Lname;
			cout << "Now please enter student's ID number: " << endl;
			cin.getline(ID, ssize);
			cin >> ID;

			while (ID == NULL)
			{
				cout << "Invalid ID number: " << endl;
				cout << "Please re-enter the student's ID number: " << endl;
				cin >> ID;
			}

			cout << "Would you like to: " << endl;
			cout << "1) View " << endl;
			cout << "2) Edit " << endl;
			cout << "3) Exit " << endl;
			cin >> choice;

			while (choice != 3)
			{
				if (choice == 1)
				{
					cout << "Would you like to view: " << endl;
					cout << "1) Student name and ID number " << endl;
					cout << "2) Course(s) the student is currently registered " << endl;
					cout << "3) Student exam scores " << endl;
					cout << "4) Student GPA for the semester " << endl;
					cout << "5) Exit " << endl;
					cin >> choice;

					while (choice != 5)
					{
						if (choice == 1)
						{
							cout << "Student name and ID number is: " << endl;
							cout << Fname << " ";
							cout << Lname;
							cout << ", " << ID << endl;
							cout << "Would you like view any of the other choices? " << endl;
							cout << "2) Course(s) the student is currently registered " << endl;
							cout << "3) Student exam scores " << endl;
							cout << "4) Student GPA for the semester " << endl;
							cout << "5) Exit " << endl;
							cin >> choice;
						}

						if (choice == 2)
						{
							cout << "Student is currently registered for: " << endl;
							ifstream myfile("Courses.txt");
							if (myfile.is_open())
							{
								while (getline(myfile, line))
								{
									cout << line << endl;
								}
								myfile.close();
							}
							else cout << "Unable to pull up student's courses. " << endl;

							cout << "Would you like to view any of the other choices? " << endl;
							cout << "1) Student name and ID number " << endl;
							cout << "3) Student exam scores " << endl;
							cout << "4) Student GPA for the semester " << endl;
							cout << "5) Exit " << endl;
							cin >> choice;
						}

						if (choice == 3)
						{
							
							cout << "Students exam scores are : " << endl;
							ifstream myfile("ExamScore.txt");
							if (myfile.is_open())
							{
								while (getline(myfile, line))
								{
									cout << line << endl;
								}
								myfile.close();
							}
							else cout << "Unable to pull up students exam scores. " << endl;

							cout << "Would you like to view any of the other choices? " << endl;
							cout << "1) Student name and ID number " << endl;
							cout << "2) Course(s) Student currently registered " << endl;
							cout << "4) Student GPA for the semester " << endl;
							cout << "5) Exit " << endl;
							cin >> choice;
						}

						else
						{
							cout << "The student GPA for the semester is: " << endl;
							cout << " " << endl;
							cout << "Would you like to view any of the other choices? " << endl;
							cout << "1) Student name and ID number " << endl;
							cout << "2) Course(s) student currently registered " << endl;
							cout << "3) Student exam scores " << endl;
							cout << "5) Exit " << endl;
							cin >> choice;
						}
					}
				
				}

				if (choice == 2)
				{
					cout << "What would you like to edit: " << endl;
					cout << "1) Exam scores " << endl;
					cout << "2) Semester GPA " << endl;
					cout << "3) Exit " << endl;
					cin >> choice;

					while (choice != 3)
					{
						if (choice == 1)
						{
							while (choice1 != 2)
							{
								ofstream myfile("ExamScore.txt");
								if (myfile.is_open())
								{

									/*cout << "Please enter the exam score: " << endl;
									cin >> exam;
									cout << "Would you like to add another exam score? " << endl;
									cout << "1) yes " << endl;
									cout << "2) no " << endl;
									cin >> choice1;
									myfile << exam;*/
									myfile << "100 " << endl;
									myfile << "98 " << endl;
									myfile.close();
								}
								else cout << "Couldn't open file: " << endl;
							}
						}

						else
						{

						}
					}
				}

				else
				{

				}
			}
		}


	system("PAUSE");
	return 0;
}